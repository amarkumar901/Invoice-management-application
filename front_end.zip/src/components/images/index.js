import { ReactComponent as ABCLogo } from './ABCLogoFull.svg';
import { ReactComponent as HRCLogo } from './hrcLogo.svg';

export {
    ABCLogo,
    HRCLogo,
}