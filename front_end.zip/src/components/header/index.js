import { ABCLogo, HRCLogo } from '../images'
import './style.css'
const Header = (props) => {
  return (<>
    <div className="Header">
      <div className="ABCConainer">
        <div className="ABCLogo">
          <ABCLogo />
        </div>
      </div>

      <div sx={{ display: { xs: 'none', lg: 'block', xl: 'none' } }} className="HRCLogo">
        <HRCLogo />
      </div>
    </div>
    <h1 id="invoice-list">Invoice List</h1>
  </>
  )
}
export default Header