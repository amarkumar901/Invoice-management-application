package com.crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.pojo.Students;


public class Crud {
	
	public Connection getConnection()
	{
		 Connection conn =null;
		 String url ="jdbc:mysql://localhost:3306/grey_goose";
		 String user = "root";
		 String pass ="root";
			
			
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn =DriverManager.getConnection(url,user,pass);
				} catch (ClassNotFoundException e) {
					
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
				return conn;

		}
	
	
	public ArrayList<Students> getData()
	{
		ArrayList<Students> ALLStudents =new ArrayList<Students>();
		int sl_no,cust_number,buisness_year,posting_id,invoice_id,isOpen,is_deleted;
		double total_open_amount;
		String business_code,doc_id,clear_date,posting_date,document_create_date,due_in_date,invoice_currency,document_type,
		baseline_create_date,cust_payment_terms,aging_bucket;
		try {
		 Connection conn = getConnection();
		 String sql_query="SELECT * from winter_internship";
		 PreparedStatement pst = conn.prepareStatement(sql_query);
		 
		 //Statement interface provides methods to execute queries with the database
		 //PreparedStatement interface is a subinterface of Statement. It is used to execute parameterized query.
		 
		 ResultSet rs = pst.executeQuery();//ResultSet maintains a cursor pointing to a row of a table
		
		 while(rs.next())
		 {
				Students s = new Students();
			 	sl_no = rs.getInt("sl_no");
			 	cust_number = rs.getInt("cust_number");
			 	buisness_year = rs.getInt("buisness_year");
			 	doc_id =  rs.getString("doc_id");
			 	posting_id = rs.getInt("posting_id");
			 	
			 	business_code = rs.getString("business_code");
			 	clear_date = rs.getString("clear_date");
			 	posting_date = rs.getString("posting_date");
			 	document_create_date = rs.getString("document_create_date");
			 	due_in_date = rs.getString("due_in_date");
			 	invoice_currency = rs.getString("invoice_currency");
			 	document_type = rs.getString("document_type");
			 	total_open_amount=rs.getDouble("total_open_amount");
			 	baseline_create_date=rs.getString("baseline_create_date");
			 	cust_payment_terms=rs.getString("cust_payment_terms");
			 	invoice_id=rs.getInt("invoice_id");
//			 	isOpen=rs.getInt("isOpen");
//			 	aging_bucket=rs.getString("aging_bucket");
			 	
				//calling setters
				
				s.setSl_no(sl_no);
				s.setCust_number(cust_number);
				s.setBuisness_year(buisness_year);
				s.setDoc_id(doc_id);
				s.setPosting_id(posting_id);
				
				s.setBusiness_code(business_code);
				s.setClear_date(clear_date);
				s.setPosting_date(posting_date);
				s.setDocument_create_date(document_create_date);
				s.setDue_in_date(due_in_date);
				s.setInvoice_currency(invoice_currency);
				s.setDocument_type(document_type);
				s.setTotal_open_amount(total_open_amount);
				s.setBaseline_create_date(baseline_create_date);
				s.setCust_payment_terms(cust_payment_terms);
				s.setInvoice_id(invoice_id);
			
				
				ALLStudents.add(s);
				
				
		 }
			 
			 for(Students stud: ALLStudents)
			 {
				 System.out.println(stud.toString());
			 }
			 
			}
			catch (Exception e) {
				e.printStackTrace();
				System.out.println("exception occur");
			}
			
			return ALLStudents;
			
		
		}
		
		public void crudOperations() {
			
			String continuedata="";
			do {
				System.out.println("Select option from below menu:");
				System.out.println("Press 1 to select data\nPress 2 to insert data\nPress 3 to delete data\n");
				
				Scanner in = new Scanner(System.in);
				var n = in.nextLine();
				
				switch(n) {
				
				case "1": try {
					Connection conn = getConnection();
					Statement statement = conn.createStatement();
					String query = "SELECT * FROM winter_internship";
					
					ResultSet rs = statement.executeQuery(query);
					
					while(rs.next()) {
						var str = String.format("%d %s %d %s %d %d %s %s %s %s %s %s %d %s %s %s %s %s %s %s %s", rs.getInt(1),rs.getString(2),rs.getInt(3),
								rs.getString(4),rs.getInt(5),rs.getLong(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),
								rs.getString(11),rs.getString(12),rs.getInt(13),rs.getString(14),rs.getString(15),rs.getString(16),rs.getString(17),
								rs.getString(18),rs.getString(19),rs.getString(20),rs.getString(21));
						
						System.out.println(str);
					}
				}catch(SQLException e) {
					e.printStackTrace();
				}
				break;
				
				case "2" : try {
					Connection conn = getConnection();
					
					System.out.println("Enter Serial number:");
					var sl_no = in.nextInt();
					System.out.println(sl_no);
					in.nextLine();
					System.out.println("Enter business code:");
					var business_code = in.nextLine();
					System.out.println(business_code);
					
					System.out.println("Enter Customer number:");
					var customer_number = in.nextInt();
					System.out.println(customer_number);
					in.nextLine();
					System.out.println("Enter clear date:");
					var clear_date = in.nextLine();
					System.out.println(clear_date);
					
					System.out.println("Enter business year:");
					var business_year = in.nextInt();
					System.out.println(business_year);
					in.nextLine();
					System.out.println("Enter Document ID:");
					var doc_id = in.nextLine();
					System.out.println(doc_id);

					System.out.println("Enter Posting date:");
					var posting_date = in.nextLine();
					System.out.println(posting_date);
					
					System.out.println("Enter Document create date:");
					var Dcd = in.nextLine();
					System.out.println(Dcd);
					
					System.out.println("Enter Document create date1:");
					var Dcd1 = in.nextLine();
					System.out.println(Dcd1);
					
					System.out.println("Enter Due in date:");
					var duedate = in.nextLine();
					System.out.println(duedate);
					
					System.out.println("Enter Invoice currency:");
					var invoice_curr = in.nextLine();
					System.out.println(invoice_curr);
					
					System.out.println("Enter Document type:");
					var documenttype = in.nextLine();
					System.out.println(documenttype);
					
					System.out.println("Enter Posting ID:");
					var postingid = in.nextLine();
					System.out.println(postingid);
					
					System.out.println("Enter Area business:");
					var area = in.nextLine();
					System.out.println(area);
					
					System.out.println("Enter Total open amount:");
					var toa = in.nextLine();
					System.out.println(toa);
					
					System.out.println("Enter Baseline create date:");
					var bcd = in.nextLine();
					System.out.println(bcd);
					
					System.out.println("Enter Customer payment terms:");
					var cpt = in.nextLine();
					System.out.println(cpt);
					
					System.out.println("Enter invoice id:");
					var invoice = in.nextLine();
					System.out.println(invoice);
					
					System.out.println("Enter isOpen:");
					var isopen = in.nextLine();
					System.out.println(isopen);
					
					System.out.println("Enter Aging bucket:");
					var aging = in.nextLine();
					System.out.println(aging);
					
					System.out.println("Enter isDeleted:");
					var deleted = in.nextLine();
					System.out.println(deleted);
					
					PreparedStatement stmt = conn.prepareStatement("INSERT INTO winter_internship"+"(sl_no,business_code,cust_number,clear_date,"
							+ "buisness_year,doc_id,posting_date,document_create_date,document_create_date1,due_in_date,invoice_currency,document_type,posting_id,"
							+ "area_business,total_open_amount,baseline_create_date,cust_payment_terms,invoice_id,isOpen,aging_bucket,is_deleted)"+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					
					stmt.setInt(1,sl_no);
					stmt.setString(2,business_code);
					stmt.setInt(3,customer_number);
					stmt.setString(4,clear_date);
					stmt.setInt(5, business_year);
					stmt.setString(6, doc_id);
					stmt.setString(7, posting_date);
					stmt.setString(8, Dcd);
					stmt.setString(9,Dcd1);
					stmt.setString(10, duedate);
					stmt.setString(11,invoice_curr);
					stmt.setString(12,documenttype);
					stmt.setString(13,postingid);
					stmt.setString(14,area);
					stmt.setString(15,toa);
					stmt.setString(16,bcd);
					stmt.setString(17,cpt);
					stmt.setString(18,invoice);
					stmt.setString(19,isopen);
					stmt.setString(20,aging);
					stmt.setString(21,deleted);
					
					stmt.executeUpdate();
					
					System.out.println("Data entered successfully");
				}catch(SQLException e) {
					e.printStackTrace();
				}
				break;
				
				case "3" : try {
					Connection conn = getConnection();
					Statement stmt = conn.createStatement();
					
					System.out.println("Enter serial number which you want to delete:");
					var id = in.nextInt();
					String delquery = "delete from winter_internship where sl_no="+id;
					stmt.executeUpdate(delquery);
					
					System.out.println("Data deleted successfully!");
				}catch(SQLException e) {
					e.printStackTrace();
				}
				break;
				
				default: System.out.println("You have selected wrong input!");
				break;
				}
				
				System.out.println("Press Y to continue: Else press any other key to exit the programe.");
				continuedata = in.nextLine();
				if(continuedata.equals("y"))
					System.out.println("You have selected to continue!");
			}while(continuedata.equals("y"));
			System.out.println("You have exited the programe!");
		}
		
		public static void main(String args[]) {
			Crud crud = new Crud();
			crud.crudOperations();
		}

}
